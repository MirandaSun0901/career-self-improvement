---
name: build-campus-mail-workbench
description: Build, deploy, diagnose, or maintain a private campus-recruitment email workbench that reads a user's mailbox, extracts recruitment events, merges company timelines, protects manual edits, and presents dashboard, archive, review, and statistics views. Use for 校招邮件工作台, 招聘邮件看板, or email-driven application tracking; do not use for mass job applications or sending email.
---

# Build Campus Mail Workbench

Build a working private application, not a mockup or product proposal. Connect a mailbox in read-only mode, persist real data, provide a usable web interface, verify the main flows, and deploy when the user authorizes deployment.

## Start

1. Inspect any existing project and preserve user data and working behavior.
2. If this is a new project, confirm only information that cannot be inferred: mailbox provider/address, authorization method, deployment target, and access-control preference.
3. Never request the mailbox login password. For QQ Mail, use IMAP with an authorization code and store it only in server-side secrets.
4. Read [references/product-rules.md](references/product-rules.md) before implementing parsing, classification, merging, deadlines, or manual-edit behavior.
5. Read [references/data-model.md](references/data-model.md) before creating or migrating the database.
6. Read [references/acceptance-tests.md](references/acceptance-tests.md) before final verification.

## Required outcome

Provide these working views using the same persisted data:

- **工作台**: company, current stage, next action, related link, deadline, status, last update, and operations.
- **待确认**: low-confidence recruitment emails that can be ignored or converted into a record.
- **邮件归档**: readable decoded email bodies, searchable and filterable, newest first.
- **统计**: company count, process-email count, completion rate, pending confirmation, stage/status distribution, deadlines, and company interaction frequency.

Each company opens a newest-first timeline of its source emails. Do not display or infer a job-position field.

## Scan behavior

- Initial connection may backfill the latest 30 days once.
- Manual “立即扫描” and scheduled scans read only the latest 3 days.
- Process and save one message at a time so earlier results survive later errors or timeouts.
- Deduplicate primarily by Message-ID, with sender, subject, and sent time as fallback evidence.
- After scanning, bypass stale caches and refresh all visible counts and lists before reporting completion.

## Data protection invariants

- Mailbox access is read-only: never send, move, delete, mark, or alter source email.
- A manual create, edit, or status change takes precedence over automatic extraction.
- Rescans may append new source events and fill empty unprotected fields, but must not overwrite protected fields.
- Opening or cancelling a “创建待办” form must not remove the email from 待确认. Remove it only after a successful database write.
- Prefer backward-compatible migrations and soft deletion. Never recreate the database to resolve a schema change.
- Do not expose authorization codes, cookies, session tokens, or internal errors in the browser, logs, URLs, or database plaintext.

## Implementation judgment

Use the existing stack when maintaining a project. For a new project, choose a mainstream full-stack framework, relational database, server-side scheduled job, and authenticated private deployment supported by the available environment. Keep extraction logic testable and separate from UI rendering.

When uncertain classification would create or change a user-facing record, place it in 待确认 rather than guessing. When a production issue is reported, inspect stored raw metadata, decoded body, extraction result, and UI aggregation separately; fix the failing layer without rewriting protected data.

## Delivery

Return the deployed private URL when deployment is requested, source code, environment-variable template without secrets, database migrations, setup instructions, and test results. Clearly identify anything that still requires the user's mailbox authorization or hosting access.
