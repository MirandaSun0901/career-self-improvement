# 校招邮件工作台 Skill

这是一个可安装的 Codex / ChatGPT Skill，用于指导开发型智能体搭建、部署和维护真实可用的校招邮件工作台。

它覆盖：邮箱只读连接、最近 3 天扫描、招聘邮件识别、正文解码、公司名称标准化、同公司时间线合并、截止时间与相关链接提取、待确认、邮件归档、统计，以及人工修改保护。

## 安装

将整个 `build-campus-mail-workbench` 文件夹复制到你的 Skills 目录，或把本仓库作为 Skill 导入。入口文件是 `SKILL.md`。

## 使用示例

```text
使用 $build-campus-mail-workbench，为我搭建一个连接 QQ 邮箱的校招邮件工作台，并部署为仅本人可访问的网站。
```

维护已有项目时：

```text
使用 $build-campus-mail-workbench，检查为什么这封测评邮件没有进入看板，并修复后验证；不要覆盖我的人工修改。
```

## 目录

```text
build-campus-mail-workbench/
├── SKILL.md
├── agents/openai.yaml
└── references/
    ├── product-rules.md
    ├── data-model.md
    └── acceptance-tests.md
```

## 安全说明

Skill 要求邮箱仅以只读方式连接。QQ 邮箱应使用 IMAP 授权码，而不是登录密码；授权信息必须存放在服务端密钥中，不能提交到 GitHub。
