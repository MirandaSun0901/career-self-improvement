# Product and extraction rules

## 1. Email body parsing

Support UTF-8, GBK, GB2312, GB18030, quoted-printable, Base64, `multipart/alternative`, `multipart/mixed`, HTML, and plain text.

- Compare candidate body parts and select the most complete meaningful body; never blindly keep the first MIME part.
- Prevent fragments such as “孙韩：” or half an HTML tag from replacing a complete body.
- Strip scripts, styles, tracking pixels, MIME boundaries, and markup while preserving readable paragraphs and line breaks.
- Keep enough body text for the archive and timeline. Do not store only a short preview.
- For legacy truncated or encoded records, backfill only the body/source event; do not overwrite manual application fields.

## 2. Recruitment classification

Classify from subject first, then body. An explicit process subject outweighs generic footer text.

### Enter the workbench

- online/综合/性格 assessment and English `Assessment`
- written test or online exam
- AI interview, interview invitation, confirmation, scheduling, rescheduling, second/final interview
- request to supplement résumé/materials or upload transcript/portfolio
- medical exam, background check, offer, signing, tripartite agreement, onboarding

If the subject clearly contains a process action, do not reject it merely because the body contains generic phrases such as “感谢投递” or “职位推荐”.

### Archive but exclude from the main workbench

- explicit rejection: “很遗憾”“本次未通过”“未能进入下一轮”“暂不匹配”“本次未录用”
- delivery receipts, application submitted/success messages
- recruitment news, job recommendations, communities, courses, livestreams, lectures, marketing, promotions, and unsubscribe mail

Do not classify a test invitation as a rejection because instructions contain conditional words such as “未通过” or “无法进入”.

### Pending confirmation

Put low-confidence mail, unclear company identity, or unclear requested action into 待确认. Preserve it until the user ignores it or successfully creates a record.

## 3. Company normalization

Keep only the company name; do not display an email address or job title.

Priority: explicit company in subject → company in body → sender display name → sender domain/maintained alias map → pending confirmation.

- Remove quotes, angle brackets, email addresses, and suffixes such as 招聘、校园招聘、校招、招聘团队、招聘助手.
- Map Chinese/English aliases to one canonical name where evidence is reliable.
- Do not treat recruiting platforms such as iTalent, 北森, Moka, 牛客, or SHL as the employer. Infer the real employer from subject/body.
- Maintain an editable alias/domain mapping table.

Examples:

| Raw evidence | Canonical company |
|---|---|
| `"ANKER" <anker-xxx@...>` | 安克 |
| `京东招聘 <campus@jd.com>` | 京东 |
| `CVTE校园招聘 <campus@cvte.io>` | CVTE |
| `来自 DJI 大疆的测评邀请` | 大疆 |
| sender=iTalent, body mentions 基恩士 | 基恩士 |

## 4. Company merge and timeline

Merge by canonical company identity, supported by normalized name, trusted domain, and alias map. Never merge solely because subjects resemble each other.

- One company has one application record and multiple immutable email events.
- Preserve all source events when merging duplicates; archive duplicate application shells rather than deleting events.
- Current stage, next action, deadline, and related link derive from the newest valid process event unless a protected manual value exists.
- Timeline and company list sort by newest event first.
- Example: 京东 assessment followed by 京东 AI interview becomes one 京东 record. Current stage is AI面试; the earlier assessment remains in the timeline.

## 5. Deadline extraction

Priority: explicit absolute time → explicit relative validity period → sent time + 48 hours.

- Parse `8月30日18:00前`, ISO dates, and similar absolute forms.
- Parse `收到邮件后72小时`, `邮件发送后48h`, `5天内完成`, `有效期为5个自然日`, and `限时3日` relative to sent time.
- Distinguish completion time from duration: “有效期5个自然日，答题时长70分钟” means +5 days, not +70 minutes.
- Normalize internally to a known timezone and display in Asia/Shanghai unless the user chooses another timezone.
- Apply the +48-hour fallback whenever a related process email exists and no deadline is recognized, even when the stage is “其他”.
- Never overwrite a protected manual deadline.

## 6. Related links

Extract from HTML `href` attributes and bare URLs. Rank assessment, written-test, interview, scheduling, meeting, material-submission, and candidate-system links highest.

Filter unsubscribe, marketing tracking, images, logos, static assets, privacy policy, and tracking pixels. Normalize malformed `http://mailto:` to `mailto:`. Show a safe clickable action in the workbench and preserve event-level links in the timeline.

## 7. Manual protection

Track manual overrides per field when practical: company, stage, next action, related link, deadline, and status. A status-only edit must not unintentionally lock unrelated fields.

Display manual values immediately after save. Automatic aggregation must check overrides before replacing display values. Rescans may add new events but may update only empty, unprotected fields.
