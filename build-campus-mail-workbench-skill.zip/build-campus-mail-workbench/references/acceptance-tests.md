# Acceptance tests

Run automated tests for extraction/aggregation and manually verify the critical user journeys.

## Parsing and classification

1. DJI assessment email becomes 大疆 / 在线测评 / 完成在线测评.
2. `有效期5个自然日，答题时长70分钟` yields sent time +5 days.
3. 安踏 assessment remains included even if its footer contains “感谢投递” or “职位推荐”.
4. iTalent mail whose body names 赛轮集团 becomes 赛轮集团, not iTalent.
5. 岚图 AI interview and English `Assessment` subjects enter the workbench.
6. An explicit rejection is archived and excluded from the main workbench.
7. An instruction containing conditional “未通过” is not misclassified as a rejection.
8. Multipart mail with a first part of only “孙韩：” selects the complete HTML/plain-text body.
9. Base64, quoted-printable, GBK, and UTF-8 Chinese bodies render readably.
10. HTML action link is extracted while image, tracking, and unsubscribe links are filtered.

## Aggregation and deadlines

11. 京东 assessment and later AI interview merge into one company record; AI面试 is current and both events remain.
12. Unknown deadline becomes sent time +48 hours.
13. Records with stage “其他” still receive the +48-hour fallback.
14. Company and timeline order is newest first.
15. Rescanning the same Message-ID creates no duplicate event.

## Manual data and resilience

16. After manually editing a field, the UI immediately shows the manual value and a rescan does not overwrite it.
17. A status-only edit persists without replacing other protected fields.
18. Cancelling 创建待办 leaves the email in 待确认.
19. A failed record save leaves the source email in 待确认.
20. If the second email fails, the first already-processed email remains saved.
21. Manual scan clearly says it scans the latest 3 days and does not trigger another 30-day backfill.
22. After scanning, dashboard, archive, statistics, and counts show the database's newest values without a hard refresh.

## Security and delivery

23. Mailbox credentials never appear in client bundles, browser storage, URLs, logs, or database plaintext.
24. The mailbox connection cannot send, delete, move, or alter messages.
25. An unauthenticated visitor cannot view the private workbench.
26. Desktop and mobile layouts support workbench, review, archive, and statistics flows.
27. Production contains no mock companies, sample emails, or fabricated statistics.
