# Recommended data model

Use equivalent names when the existing project already has a schema. Preserve these relationships and invariants.

## `applications`

- `id`
- `owner_id` or `owner_email`
- `company`
- `current_stage`
- `next_action`
- `related_link`
- `deadline`
- `status`
- `source`
- `confidence`
- per-field override metadata, or `manual_locked` plus `manual_override_at`
- `archived_at`
- `created_at`, `updated_at`

## `application_events`

- `id`
- `application_id`
- `source_message_id`
- `sender`
- `subject`
- `sent_at`
- `readable_body`
- `event_type`
- `related_link`
- `extracted_deadline`
- extraction metadata/confidence
- `created_at`

## `review_emails`

- `id`
- `owner_id` or `owner_email`
- `message_id`
- `sender`
- `subject`
- `sent_at`
- `readable_body`
- `confidence`
- `decision`
- `created_at`, `updated_at`

## `mailbox_settings`

- `owner_id` or `owner_email`
- `mailbox_email`
- encrypted authorization material or secret reference
- `enabled`
- `initial_backfill_completed_at`
- `last_sync_at`
- `last_sync_status`
- `created_at`, `updated_at`

## `company_aliases`

- `id`
- `canonical_company`
- `alias` and/or `sender_domain`
- `source`
- `created_at`, `updated_at`

## Required constraints and indexes

- unique mailbox event identity on owner + `source_message_id`
- fallback duplicate check on owner, sender, subject, and sent time
- indexes for company, deadline, status, stage, sent/event time, and review decision
- foreign-key protection between applications and events
- migrations must be backward-compatible and preserve existing rows

Raw email storage is optional. If retained for debugging, minimize scope, encrypt sensitive content, define retention, and never expose it to clients.
